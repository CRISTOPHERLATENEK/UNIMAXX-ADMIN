/**
 * BrandThemeContext
 * Fonte única de verdade para o tema da marca.
 *
 * - Lê e salva via /api/admin/settings (chave-valor, igual ao restante do sistema)
 * - Injeta CSS custom properties no :root para consumo global
 * - Cache local para evitar flash de estilo (FOUT) no carregamento
 * - Expõe `brandTheme` tipado + `saveBrandTheme()` para o ThemeEditor
 *
 * Uso nos componentes (sem hardcode de cor):
 *   style={{ color: 'var(--brand-primary)' }}
 *   style={{ fontFamily: 'var(--font-heading)' }}
 */

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from 'react';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface BrandTheme {
  primaryColor:   string;
  secondaryColor: string;
  accentColor:    string;
  successColor:   string;
  warningColor:   string;
  errorColor:     string;
  fontHeading:    string;
  fontBody:       string;
  baseFontSize:   string;
  borderRadius:   string;
  maxWidth:       string;
  customCss:      string;
}

interface BrandThemeContextType {
  brandTheme:     BrandTheme;
  loading:        boolean;
  saveBrandTheme: (updates: Partial<BrandTheme>) => Promise<void>;
  resetBrandTheme: () => void;
}

// ─── Defaults (espelham index.css atual) ──────────────────────────────────────

export const DEFAULT_BRAND_THEME: BrandTheme = {
  primaryColor:   '#f97316',
  secondaryColor: '#1e293b',
  accentColor:    '#f97316',
  successColor:   '#22c55e',
  warningColor:   '#f59e0b',
  errorColor:     '#ef4444',
  fontHeading:    'Outfit',
  fontBody:       'DM Sans',
  baseFontSize:   '16px',
  borderRadius:   '0.75rem',
  maxWidth:       '1280px',
  customCss:      '',
};

// ─── Mapeamento: settings key → BrandTheme field ──────────────────────────────

function settingsToBrandTheme(s: Record<string, string>): BrandTheme {
  return {
    primaryColor:   s.primary_color   || DEFAULT_BRAND_THEME.primaryColor,
    secondaryColor: s.secondary_color || DEFAULT_BRAND_THEME.secondaryColor,
    accentColor:    s.accent_color    || DEFAULT_BRAND_THEME.accentColor,
    successColor:   s.success_color   || DEFAULT_BRAND_THEME.successColor,
    warningColor:   s.warning_color   || DEFAULT_BRAND_THEME.warningColor,
    errorColor:     s.error_color     || DEFAULT_BRAND_THEME.errorColor,
    fontHeading:    s.font_heading    || DEFAULT_BRAND_THEME.fontHeading,
    fontBody:       s.font_body       || DEFAULT_BRAND_THEME.fontBody,
    baseFontSize:   s.base_font_size  || DEFAULT_BRAND_THEME.baseFontSize,
    borderRadius:   s.border_radius   || DEFAULT_BRAND_THEME.borderRadius,
    maxWidth:       s.max_width       || DEFAULT_BRAND_THEME.maxWidth,
    customCss:      s.custom_css      || '',
  };
}

function brandThemeToSettings(t: BrandTheme): Record<string, string> {
  return {
    primary_color:   t.primaryColor,
    secondary_color: t.secondaryColor,
    accent_color:    t.accentColor,
    success_color:   t.successColor,
    warning_color:   t.warningColor,
    error_color:     t.errorColor,
    font_heading:    t.fontHeading,
    font_body:       t.fontBody,
    base_font_size:  t.baseFontSize,
    border_radius:   t.borderRadius,
    max_width:       t.maxWidth,
    custom_css:      t.customCss,
  };
}

// ─── Injeção de CSS custom properties ────────────────────────────────────────

function hexToHsl(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export function applyBrandThemeToDom(theme: BrandTheme): void {
  const root = document.documentElement;

  // Cores de marca (novas vars — sem conflito com vars existentes)
  root.style.setProperty('--brand-primary',   theme.primaryColor);
  root.style.setProperty('--brand-secondary', theme.secondaryColor);
  root.style.setProperty('--brand-accent',    theme.accentColor);
  root.style.setProperty('--brand-success',   theme.successColor);
  root.style.setProperty('--brand-warning',   theme.warningColor);
  root.style.setProperty('--brand-error',     theme.errorColor);

  // Aliases de compatibilidade com vars existentes no index.css
  root.style.setProperty('--orange',      theme.primaryColor);
  root.style.setProperty('--orange-deep', theme.accentColor);
  root.style.setProperty('--orange-glow', `${theme.primaryColor}47`);

  // Vars Tailwind/shadcn (formato HSL)
  try {
    root.style.setProperty('--primary',          hexToHsl(theme.primaryColor));
    root.style.setProperty('--ring',             hexToHsl(theme.primaryColor));
    root.style.setProperty('--accent',           hexToHsl(theme.accentColor));
    root.style.setProperty('--sidebar-primary',  hexToHsl(theme.primaryColor));
    root.style.setProperty('--sidebar-ring',     hexToHsl(theme.primaryColor));
  } catch { /* hex inválido: mantém valor anterior */ }

  // Tipografia
  root.style.setProperty('--font-heading',   `'${theme.fontHeading}', sans-serif`);
  root.style.setProperty('--font-body',      `'${theme.fontBody}', sans-serif`);
  root.style.setProperty('--font-size-base', theme.baseFontSize);

  // Layout
  root.style.setProperty('--radius',    theme.borderRadius);
  root.style.setProperty('--max-width', theme.maxWidth);

  // Google Fonts dinâmico
  const fontNames = [theme.fontHeading, theme.fontBody].filter(Boolean).join('&family=');
  const href = `https://fonts.googleapis.com/css2?family=${fontNames.replace(/ /g, '+')}:wght@300;400;500;600;700;800;900&display=swap`;
  const linkId = 'brand-theme-fonts';
  const existing = document.getElementById(linkId) as HTMLLinkElement | null;
  if (existing) {
    existing.href = href;
  } else {
    const link = document.createElement('link');
    link.id = linkId;
    link.rel = 'stylesheet';
    link.href = href;
    document.head.appendChild(link);
  }

  // CSS personalizado
  const styleId = 'brand-theme-custom-css';
  let styleEl = document.getElementById(styleId) as HTMLStyleElement | null;
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = styleId;
    document.head.appendChild(styleEl);
  }
  styleEl.textContent = theme.customCss || '';
}

// ─── Cache local ──────────────────────────────────────────────────────────────

const CACHE_KEY = 'brand_theme_cache';

function loadCachedTheme(): BrandTheme | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as BrandTheme) : null;
  } catch { return null; }
}

function saveCachedTheme(theme: BrandTheme): void {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(theme)); } catch { }
}

// ─── Context ──────────────────────────────────────────────────────────────────

const BrandThemeContext = createContext<BrandThemeContextType | undefined>(undefined);

export function BrandThemeProvider({ children }: { children: ReactNode }) {
  const cached = loadCachedTheme();
  const [brandTheme, setBrandTheme] = useState<BrandTheme>(cached ?? DEFAULT_BRAND_THEME);
  const [loading, setLoading] = useState(!cached);

  // Aplica cache imediatamente para evitar FOUT
  useEffect(() => {
    if (cached) applyBrandThemeToDom(cached);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Carrega do backend (GET /api/data → settings)
  useEffect(() => {
    async function fetch_() {
      try {
        const res = await fetch('/api/data');
        if (!res.ok) return;
        const json = await res.json();
        const s: Record<string, string> = json?.settings ?? {};
        const theme = settingsToBrandTheme(s);
        setBrandTheme(theme);
        saveCachedTheme(theme);
        applyBrandThemeToDom(theme);
      } catch { /* usa cache ou defaults */ }
      finally { setLoading(false); }
    }
    fetch_();
  }, []);

  const saveBrandTheme = useCallback(async (updates: Partial<BrandTheme>) => {
    const next = { ...brandTheme, ...updates };
    setBrandTheme(next);
    applyBrandThemeToDom(next);
    saveCachedTheme(next);

    const token = localStorage.getItem('token');
    await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(brandThemeToSettings(next)),
    });
  }, [brandTheme]);

  const resetBrandTheme = useCallback(() => {
    setBrandTheme(DEFAULT_BRAND_THEME);
    applyBrandThemeToDom(DEFAULT_BRAND_THEME);
    saveCachedTheme(DEFAULT_BRAND_THEME);
  }, []);

  return (
    <BrandThemeContext.Provider value={{ brandTheme, loading, saveBrandTheme, resetBrandTheme }}>
      {children}
    </BrandThemeContext.Provider>
  );
}

export function useBrandTheme(): BrandThemeContextType {
  const ctx = useContext(BrandThemeContext);
  if (!ctx) throw new Error('useBrandTheme deve ser usado dentro de <BrandThemeProvider>');
  return ctx;
}
