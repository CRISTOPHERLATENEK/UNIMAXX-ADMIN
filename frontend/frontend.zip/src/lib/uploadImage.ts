/**
 * uploadImage — utilitário centralizado de upload de imagem.
 *
 * Chama POST /api/admin/upload e retorna { url, srcset }.
 * `srcset` é { lg, md, sm } quando o backend tem Sharp instalado,
 * ou null em uploads legados sem Sharp.
 *
 * Use em todos os managers que fazem upload de imagem para garantir
 * que o campo srcset seja salvo junto com a URL principal.
 */

const API_URL = (import.meta.env?.VITE_API_URL || 'http://localhost:3001/api') as string;

export interface UploadResult {
  url: string;
  srcset: { lg: string; md: string; sm: string } | null;
}

export async function uploadImage(file: File): Promise<UploadResult> {
  const fd = new FormData();
  fd.append('image', file);

  const res = await fetch(`${API_URL}/admin/upload`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    body: fd,
  });

  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error || 'Upload falhou');
  }

  const data = await res.json();

  return {
    url:    data.url,
    srcset: data.srcset ?? null,
  };
}
