/**
 * PreviewView — renderiza uma página pelo token compartilhável.
 * Rota: /preview/:token
 * Sem autenticação, sem header/footer admin, com banner de aviso de preview.
 */
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { AlertCircle, Clock, Eye, RefreshCw } from 'lucide-react';
import { Header } from '@/sections/Header';
import { Footer } from '@/sections/Footer';
import { BlockRenderer, THEME, DEFAULT_T } from '@/pages/BlockRenderer';
import type { PageBlock } from '@/types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

function formatExpiry(isoDate: string) {
  const d = new Date(isoDate);
  const diff = d.getTime() - Date.now();
  if (diff <= 0) return 'Expirado';
  const h = Math.floor(diff / 3_600_000);
  if (h < 1) return 'Expira em menos de 1 hora';
  if (h < 24) return `Expira em ${h} hora${h > 1 ? 's' : ''}`;
  const days = Math.floor(h / 24);
  return `Expira em ${days} dia${days > 1 ? 's' : ''}`;
}

export default function PreviewView() {
  const { token } = useParams<{ token: string }>();
  const [pageData, setPageData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    if (!token) { setError('Token inválido'); setLoading(false); return; }
    try {
      setLoading(true); setError(null);
      const res = await fetch(`${API_URL}/preview/${token}`);
      if (res.status === 404) throw new Error('Este link de preview não existe ou expirou.');
      if (!res.ok) throw new Error('Erro ao carregar preview.');
      setPageData(await res.json());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro desconhecido');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [token]);

  useEffect(() => {
    if (pageData?.page) {
      document.title = `[PREVIEW] ${pageData.page.meta_title || pageData.page.title}`;
    }
    return () => { document.title = 'Unimaxx'; };
  }, [pageData]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 rounded-full border-2 border-gray-200 animate-spin" style={{ borderTopColor: '#f97316' }} />
        <p className="text-gray-400 text-sm">Carregando preview…</p>
      </div>
    </div>
  );

  if (error || !pageData) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="w-10 h-10 text-red-400" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-3" style={{ fontFamily: "'Outfit',sans-serif" }}>
          Preview indisponível
        </h1>
        <p className="text-gray-500 mb-8">{error || 'Link inválido ou expirado.'}</p>
        <button onClick={load} className="flex items-center gap-2 px-5 py-2.5 rounded-full text-white text-sm font-medium mx-auto" style={{ background: '#f97316' }}>
          <RefreshCw className="w-4 h-4" /> Tentar novamente
        </button>
      </div>
    </div>
  );

  const { page, page_type, expires_at, label } = pageData;
  const t = page_type === 'solution_page' ? (THEME[page.color_theme] || THEME.orange) : DEFAULT_T;
  const blocks: PageBlock[] = (page.blocks_json || []).filter((b: PageBlock) => b.visible);

  return (
    <div className="min-h-screen" style={{ fontFamily: "'DM Sans',sans-serif" }}>
      {/* Banner de aviso */}
      <div className="w-full py-2 px-4 flex items-center justify-center gap-2 text-sm font-medium flex-wrap"
        style={{ background: '#1d1d1f', color: '#fff' }}>
        <Eye className="w-4 h-4 text-orange-400 flex-shrink-0" />
        <span>Você está vendo um <strong className="text-orange-400">preview</strong> — este conteúdo ainda não foi publicado</span>
        {label && <span className="opacity-50">·</span>}
        {label && <span className="opacity-70">{label}</span>}
        <span className="opacity-50">·</span>
        <span className="flex items-center gap-1 opacity-70">
          <Clock className="w-3.5 h-3.5" /> {formatExpiry(expires_at)}
        </span>
        {!page.is_active && (
          <>
            <span className="opacity-50">·</span>
            <span className="text-yellow-400">⚠ Página inativa (não publicada)</span>
          </>
        )}
      </div>

      <Header />

      {blocks.length > 0
        ? blocks.map((block) => <BlockRenderer key={block.id} block={block} t={t} />)
        : (
          <div className="min-h-[60vh] flex items-center justify-center px-4">
            <div className="text-center">
              <p className="text-5xl mb-4">🏗️</p>
              <h2 className="text-xl font-bold text-gray-800 mb-2" style={{ fontFamily: "'Outfit',sans-serif" }}>
                Página sem blocos
              </h2>
              <p className="text-gray-500">Esta página ainda não tem conteúdo configurado.</p>
            </div>
          </div>
        )
      }

      <Footer />
    </div>
  );
}
