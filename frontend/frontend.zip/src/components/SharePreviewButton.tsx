/**
 * SharePreviewButton
 * Botão que abre um popover para criar e gerenciar links de preview
 * temporários para páginas do construtor.
 *
 * Uso:
 *   <SharePreviewButton
 *     pageType="generic_page"
 *     pageId={form.id}        // string ou number
 *     pageLabel={form.title}
 *   />
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  Link2, Copy, Check, Trash2, RefreshCw, ExternalLink,
  Clock, ChevronDown, Share2, X,
} from 'lucide-react';
import { usePreviewTokens, type PreviewToken } from '@/hooks/usePreviewTokens';

interface Props {
  pageType: 'generic_page' | 'solution_page';
  pageId: string | number;
  pageLabel?: string;
  /** Se omitido, o botão fica desabilitado */
  disabled?: boolean;
}

function formatExpiry(isoDate: string) {
  const d = new Date(isoDate);
  const diff = d.getTime() - Date.now();
  if (diff <= 0) return 'Expirado';
  const h = Math.floor(diff / 3_600_000);
  if (h < 1) return 'Expira em < 1h';
  if (h < 24) return `Expira em ${h}h`;
  const days = Math.floor(h / 24);
  return `Expira em ${days}d`;
}

const EXPIRE_OPTIONS = [
  { label: '24 horas', value: 24 },
  { label: '48 horas', value: 48 },
  { label: '7 dias',   value: 168 },
  { label: '30 dias',  value: 720 },
];

export function SharePreviewButton({ pageType, pageId, pageLabel = '', disabled }: Props) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [expiresHours, setExpiresHours] = useState(48);
  const [showExpiry, setShowExpiry] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  const { tokens, loading, error, fetchTokens, createToken, revokeToken, buildUrl } =
    usePreviewTokens();

  // Carrega tokens ao abrir
  useEffect(() => {
    if (open && pageId) fetchTokens(pageType, pageId);
  }, [open, pageId, pageType]);

  // Fecha ao clicar fora
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const handleCreate = async () => {
    if (!pageId) return;
    const t = await createToken({
      page_type: pageType,
      page_id: pageId,
      label: pageLabel,
      expires_hours: expiresHours,
    });
    if (t) handleCopy(t.token);
  };

  const handleCopy = (token: string) => {
    navigator.clipboard.writeText(buildUrl(token)).then(() => {
      setCopied(token);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  if (disabled || !pageId) {
    return (
      <button
        disabled
        title="Salve a página primeiro para compartilhar preview"
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-medium opacity-40 cursor-not-allowed"
        style={{ color: '#6e6e73', background: '#f5f5f7' }}
      >
        <Share2 style={{ width: 13, height: 13 }} /> Compartilhar
      </button>
    );
  }

  return (
    <div style={{ position: 'relative' }} ref={popoverRef}>
      {/* Trigger */}
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-medium transition"
        style={{
          color: open ? '#f97316' : '#6e6e73',
          background: open ? '#fff3eb' : '#f5f5f7',
          border: open ? '1px solid #fed7aa' : '1px solid transparent',
        }}
        onMouseEnter={(e) => {
          if (!open) (e.currentTarget as HTMLElement).style.background = '#e5e5ea';
        }}
        onMouseLeave={(e) => {
          if (!open) (e.currentTarget as HTMLElement).style.background = '#f5f5f7';
        }}
      >
        <Share2 style={{ width: 13, height: 13 }} />
        Compartilhar
        {tokens.length > 0 && (
          <span
            className="text-[10px] font-bold rounded-full px-1.5 py-0.5"
            style={{ background: '#f97316', color: '#fff', lineHeight: 1 }}
          >
            {tokens.length}
          </span>
        )}
      </button>

      {/* Popover */}
      {open && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: 0,
            width: 340,
            background: '#fff',
            border: '1px solid rgba(0,0,0,.08)',
            borderRadius: 16,
            boxShadow: '0 8px 40px rgba(0,0,0,.13)',
            zIndex: 100,
            overflow: 'hidden',
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3"
            style={{ borderBottom: '1px solid rgba(0,0,0,.06)' }}
          >
            <div className="flex items-center gap-2">
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center"
                style={{ background: '#fff3eb' }}
              >
                <Link2 style={{ width: 14, height: 14, color: '#f97316' }} />
              </div>
              <span className="font-semibold text-[13px]" style={{ color: '#1d1d1f' }}>
                Preview compartilhável
              </span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="w-6 h-6 flex items-center justify-center rounded-lg transition"
              style={{ color: '#98989d' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = '#f5f5f7'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
            >
              <X style={{ width: 13, height: 13 }} />
            </button>
          </div>

          {/* Create area */}
          <div className="px-4 py-3" style={{ borderBottom: '1px solid rgba(0,0,0,.06)' }}>
            <p className="text-[11px] mb-3" style={{ color: '#6e6e73', lineHeight: 1.5 }}>
              Gere um link temporário para que o cliente veja o conteúdo
              <strong style={{ color: '#1d1d1f' }}> sem precisar de login</strong>.
            </p>

            <div className="flex gap-2">
              {/* Expiry selector */}
              <div style={{ position: 'relative', flex: '0 0 auto' }}>
                <button
                  onClick={() => setShowExpiry(!showExpiry)}
                  className="flex items-center gap-1 px-3 h-9 rounded-xl text-[12px] font-medium transition"
                  style={{ background: '#f5f5f7', color: '#1d1d1f', border: '1px solid rgba(0,0,0,.06)' }}
                >
                  <Clock style={{ width: 12, height: 12, color: '#6e6e73' }} />
                  {EXPIRE_OPTIONS.find((o) => o.value === expiresHours)?.label}
                  <ChevronDown style={{ width: 11, height: 11, color: '#98989d' }} />
                </button>

                {showExpiry && (
                  <div
                    style={{
                      position: 'absolute',
                      top: 'calc(100% + 4px)',
                      left: 0,
                      background: '#fff',
                      border: '1px solid rgba(0,0,0,.08)',
                      borderRadius: 12,
                      boxShadow: '0 4px 20px rgba(0,0,0,.1)',
                      zIndex: 200,
                      overflow: 'hidden',
                      minWidth: 130,
                    }}
                  >
                    {EXPIRE_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => { setExpiresHours(opt.value); setShowExpiry(false); }}
                        className="w-full text-left px-4 py-2.5 text-[12px] font-medium transition"
                        style={{
                          color: expiresHours === opt.value ? '#f97316' : '#1d1d1f',
                          background: expiresHours === opt.value ? '#fff3eb' : 'transparent',
                        }}
                        onMouseEnter={(e) => {
                          if (expiresHours !== opt.value)
                            (e.currentTarget as HTMLElement).style.background = '#f5f5f7';
                        }}
                        onMouseLeave={(e) => {
                          if (expiresHours !== opt.value)
                            (e.currentTarget as HTMLElement).style.background = 'transparent';
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Gerar */}
              <button
                onClick={handleCreate}
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-1.5 h-9 rounded-xl text-[12px] font-bold transition"
                style={{ background: '#f97316', color: '#fff' }}
                onMouseEnter={(e) => {
                  if (!loading) (e.currentTarget as HTMLElement).style.background = '#ea580c';
                }}
                onMouseLeave={(e) => {
                  if (!loading) (e.currentTarget as HTMLElement).style.background = '#f97316';
                }}
              >
                {loading
                  ? <RefreshCw style={{ width: 13, height: 13 }} className="animate-spin" />
                  : <><Link2 style={{ width: 13, height: 13 }} /> Gerar link</>
                }
              </button>
            </div>

            {error && (
              <p className="text-[11px] mt-2" style={{ color: '#ef4444' }}>{error}</p>
            )}
          </div>

          {/* Token list */}
          {tokens.length > 0 && (
            <div style={{ maxHeight: 220, overflowY: 'auto' }}>
              <p
                className="px-4 pt-3 pb-1 text-[10px] font-semibold uppercase tracking-wider"
                style={{ color: '#98989d' }}
              >
                Links ativos
              </p>

              {tokens.map((t: PreviewToken) => {
                const url = buildUrl(t.token);
                const isCopied = copied === t.token;

                return (
                  <div
                    key={t.token}
                    className="flex items-center gap-2 px-4 py-2.5 transition"
                    style={{ borderTop: '1px solid rgba(0,0,0,.04)' }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.background = '#fafafa';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.background = 'transparent';
                    }}
                  >
                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p
                        className="text-[11px] font-mono truncate"
                        style={{ color: '#1d1d1f' }}
                        title={url}
                      >
                        /preview/{t.token.slice(0, 12)}…
                      </p>
                      <p className="text-[10px]" style={{ color: '#98989d' }}>
                        {formatExpiry(t.expires_at)}
                      </p>
                    </div>

                    {/* Abrir */}
                    <a
                      href={url}
                      target="_blank"
                      rel="noreferrer"
                      title="Abrir preview"
                      className="w-7 h-7 flex items-center justify-center rounded-lg transition"
                      style={{ color: '#6e6e73' }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLElement).style.background = '#f5f5f7';
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLElement).style.background = 'transparent';
                      }}
                    >
                      <ExternalLink style={{ width: 13, height: 13 }} />
                    </a>

                    {/* Copiar */}
                    <button
                      onClick={() => handleCopy(t.token)}
                      title={isCopied ? 'Copiado!' : 'Copiar link'}
                      className="w-7 h-7 flex items-center justify-center rounded-lg transition"
                      style={{ color: isCopied ? '#22c55e' : '#6e6e73' }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLElement).style.background = '#f5f5f7';
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLElement).style.background = 'transparent';
                      }}
                    >
                      {isCopied
                        ? <Check style={{ width: 13, height: 13 }} />
                        : <Copy style={{ width: 13, height: 13 }} />
                      }
                    </button>

                    {/* Revogar */}
                    <button
                      onClick={() => revokeToken(t.token)}
                      title="Revogar link"
                      className="w-7 h-7 flex items-center justify-center rounded-lg transition"
                      style={{ color: '#ef4444' }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLElement).style.background = '#fef2f2';
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLElement).style.background = 'transparent';
                      }}
                    >
                      <Trash2 style={{ width: 12, height: 12 }} />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tokens.length === 0 && !loading && (
            <div className="px-4 py-4 text-center">
              <p className="text-[11px]" style={{ color: '#98989d' }}>
                Nenhum link ativo. Gere um acima.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
