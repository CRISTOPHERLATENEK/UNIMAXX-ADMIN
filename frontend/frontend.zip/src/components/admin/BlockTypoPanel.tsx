/**
 * BlockTypoPanel — painel de tipografia por bloco
 * Usado no PageLayoutManager para editar tipografia de cada seção individualmente.
 */
import React, { useState } from 'react';
import { Type, ChevronDown, ChevronUp, RotateCcw, Check } from 'lucide-react';

const FONTS_H = [
  'Outfit','Space Grotesk','Syne','Raleway','Montserrat',
  'Playfair Display','Inter','Poppins','Josefin Sans','DM Serif Display',
  'Bebas Neue','Oswald','Barlow','Manrope','Unbounded',
];
const FONTS_B = [
  'DM Sans','Inter','Plus Jakarta Sans','Nunito','Lato',
  'Open Sans','Source Sans 3','Roboto','Figtree','Mulish','Karla',
];
const WEIGHTS = [
  { v: '400', l: 'Regular' },
  { v: '500', l: 'Medium' },
  { v: '600', l: 'Semi' },
  { v: '700', l: 'Bold' },
  { v: '800', l: 'Extra' },
  { v: '900', l: 'Black' },
];

type Values = Record<string, string>;

interface BlockTypoPanelProps {
  sectionId: string;
  sectionLabel: string;
  values: Values;         // objeto { [key]: value } atual do content
  onChange: (key: string, value: string) => void;
  onSave: () => void;
  saving?: boolean;
  primaryColor?: string;
}

function ColorRow({
  label, k, values, onChange,
}: { label: string; k: string; values: Values; onChange: (k: string, v: string) => void }) {
  const v = values[k] || '';
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-semibold text-[#3a3a3c]">{label}</span>
        {v && (
          <button onClick={() => onChange(k, '')}
            className="text-[10px] text-[#98989d] hover:text-red-500 transition-colors">
            Limpar
          </button>
        )}
      </div>
      <div className="flex items-center gap-2">
        <div className="relative flex-shrink-0">
          <div className="w-8 h-8 rounded-lg border overflow-hidden cursor-pointer"
            style={{ borderColor: 'rgba(0,0,0,.12)', background: v || '#ffffff' }}>
            <input type="color" value={v || '#000000'} onChange={e => onChange(k, e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" />
          </div>
        </div>
        <input type="text" value={v} onChange={e => onChange(k, e.target.value)}
          placeholder="Padrão da seção"
          className="flex-1 h-8 px-2.5 rounded-lg border text-[11px] font-mono bg-white"
          style={{ borderColor: 'rgba(0,0,0,.1)' }} />
      </div>
    </div>
  );
}

export function BlockTypoPanel({
  sectionId, sectionLabel, values, onChange, onSave, saving, primaryColor = '#f97316',
}: BlockTypoPanelProps) {
  const [open, setOpen] = useState(false);

  const k = (prop: string) => `${sectionId}.${prop}`;
  const hasAny = [
    'typo_h_color','typo_body_color','typo_label_color',
    'font_heading','font_body','typo_h_weight','typo_body_size',
  ].some(p => !!values[k(p)]);

  const clearAll = () => {
    [
      'typo_h_color','typo_body_color','typo_label_color',
      'font_heading','font_body','typo_h_weight','typo_body_size',
      'typo_h_spacing',
    ].forEach(p => onChange(k(p), ''));
  };

  const fh = values[k('font_heading')] || '';
  const fb = values[k('font_body')]    || '';
  const hw = values[k('typo_h_weight')]|| '';

  return (
    <div className="rounded-xl border overflow-hidden"
      style={{ borderColor: hasAny ? `${primaryColor}40` : 'rgba(0,0,0,.07)', background: hasAny ? `${primaryColor}04` : '#fafafa' }}>

      {/* Header */}
      <button onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-3 py-2.5 text-left hover:bg-black/[.02] transition-colors">
        <div className="flex items-center gap-2">
          <Type className="w-3.5 h-3.5 flex-shrink-0" style={{ color: hasAny ? primaryColor : '#98989d' }} />
          <span className="text-[11px] font-semibold" style={{ color: hasAny ? primaryColor : '#6e6e73' }}>
            Tipografia{hasAny ? ' (personalizada)' : ''}
          </span>
        </div>
        {open ? <ChevronUp className="w-3.5 h-3.5 text-[#98989d]" /> : <ChevronDown className="w-3.5 h-3.5 text-[#98989d]" />}
      </button>

      {/* Panel */}
      {open && (
        <div className="px-3 pb-3 space-y-4 border-t" style={{ borderColor: 'rgba(0,0,0,.06)' }}>
          <div className="pt-3 space-y-1.5">
            <p className="text-[10px] font-bold text-[#98989d] uppercase tracking-widest">
              Tipografia de: {sectionLabel}
            </p>
            <p className="text-[10px] text-[#c7c7cc]">
              Sobrescreve o estilo global apenas nesta seção.
              Deixe em branco para usar o padrão.
            </p>
          </div>

          {/* Cores */}
          <div className="space-y-3">
            <p className="text-[10px] font-bold text-[#98989d] uppercase tracking-widest">Cores</p>
            <div className="grid grid-cols-1 gap-2.5">
              <ColorRow label="Cor dos Títulos (H1, H2, H3)" k={k('typo_h_color')} values={values} onChange={onChange} />
              <ColorRow label="Cor do Corpo (parágrafos)"    k={k('typo_body_color')} values={values} onChange={onChange} />
              <ColorRow label="Cor do Label / Badge"         k={k('typo_label_color')} values={values} onChange={onChange} />
            </div>
          </div>

          {/* Fontes */}
          <div className="space-y-3">
            <p className="text-[10px] font-bold text-[#98989d] uppercase tracking-widest">Fontes</p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-[10px] font-semibold text-[#6e6e73] mb-1.5">Títulos</p>
                <select value={fh} onChange={e => onChange(k('font_heading'), e.target.value)}
                  className="w-full h-8 px-2 rounded-lg border text-[11px] bg-white"
                  style={{ borderColor: 'rgba(0,0,0,.1)', fontFamily: fh ? `'${fh}',sans-serif` : undefined }}>
                  <option value="">— Padrão —</option>
                  {FONTS_H.map(f => <option key={f} value={f} style={{ fontFamily: `'${f}',sans-serif` }}>{f}</option>)}
                </select>
              </div>
              <div>
                <p className="text-[10px] font-semibold text-[#6e6e73] mb-1.5">Corpo</p>
                <select value={fb} onChange={e => onChange(k('font_body'), e.target.value)}
                  className="w-full h-8 px-2 rounded-lg border text-[11px] bg-white"
                  style={{ borderColor: 'rgba(0,0,0,.1)', fontFamily: fb ? `'${fb}',sans-serif` : undefined }}>
                  <option value="">— Padrão —</option>
                  {FONTS_B.map(f => <option key={f} value={f} style={{ fontFamily: `'${f}',sans-serif` }}>{f}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Peso */}
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-[#98989d] uppercase tracking-widest">Peso dos Títulos</p>
            <div className="grid grid-cols-6 gap-1">
              {WEIGHTS.map(w => (
                <button key={w.v} onClick={() => onChange(k('typo_h_weight'), hw === w.v ? '' : w.v)}
                  className="py-1.5 rounded-lg border text-[9px] font-semibold transition-all"
                  style={{
                    fontWeight: parseInt(w.v),
                    fontFamily: fh ? `'${fh}',sans-serif` : undefined,
                    borderColor: hw === w.v ? primaryColor : 'rgba(0,0,0,.1)',
                    background: hw === w.v ? `${primaryColor}12` : '#fff',
                    color: hw === w.v ? primaryColor : '#6e6e73',
                  }}>
                  {w.l}
                </button>
              ))}
            </div>
          </div>

          {/* Tamanho corpo */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-[#98989d] uppercase tracking-widest">Tamanho do Corpo</p>
              <span className="text-[10px] font-mono text-[#6e6e73]">
                {values[k('typo_body_size')] ? `${values[k('typo_body_size')]}px` : 'Padrão'}
              </span>
            </div>
            <input type="range" min={12} max={20} step={1}
              value={parseInt(values[k('typo_body_size')] || '15')}
              onChange={e => onChange(k('typo_body_size'), e.target.value)}
              className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
              style={{ accentColor: primaryColor }} />
            <div className="flex justify-between">
              <span className="text-[9px] text-[#c7c7cc]">12px</span>
              <span className="text-[9px] text-[#c7c7cc]">20px</span>
            </div>
          </div>

          {/* Preview */}
          <div className="rounded-lg p-3 space-y-1.5" style={{ background: '#f5f5f7' }}>
            <p className="text-[9px] font-bold text-[#98989d] uppercase tracking-widest mb-2">Preview</p>
            <p style={{
              fontFamily: fh ? `'${fh}',sans-serif` : "var(--font-heading,'Outfit'),sans-serif",
              fontWeight: hw ? parseInt(hw) : 800,
              fontSize: 18,
              color: values[k('typo_h_color')] || '#1d1d1f',
              lineHeight: 1.2,
              letterSpacing: '-0.02em',
            }}>
              Título da seção
            </p>
            <p style={{
              fontFamily: fb ? `'${fb}',sans-serif` : "var(--font-body,'DM Sans'),sans-serif",
              fontSize: parseInt(values[k('typo_body_size')] || '14'),
              color: values[k('typo_body_color')] || '#6e6e73',
              lineHeight: 1.6,
            }}>
              Texto de exemplo do corpo da seção com a tipografia selecionada.
            </p>
            {values[k('typo_label_color')] && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                padding: '2px 8px', borderRadius: 4,
                border: `1px solid ${values[k('typo_label_color')]}35`,
                fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: values[k('typo_label_color')],
                fontFamily: fb ? `'${fb}',sans-serif` : undefined,
              }}>
                ● Label
              </span>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 pt-1">
            <button onClick={onSave} disabled={saving}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] font-bold text-white transition-all"
              style={{ background: saving ? '#c7c7cc' : primaryColor }}>
              {saving ? 'Salvando...' : <><Check className="w-3 h-3" /> Salvar</>}
            </button>
            {hasAny && (
              <button onClick={clearAll}
                className="flex items-center gap-1 px-3 py-2 rounded-lg text-[11px] font-semibold border transition-all hover:bg-red-50 hover:border-red-300 hover:text-red-600"
                style={{ borderColor: 'rgba(0,0,0,.1)', color: '#6e6e73' }}>
                <RotateCcw className="w-3 h-3" /> Resetar
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
