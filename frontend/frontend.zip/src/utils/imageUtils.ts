/**
 * imageUtils.ts
 * Utilitário central para resolver URLs de imagens do backend.
 *
 * Regras:
 * - Remove /api do sufixo da VITE_API_URL para obter a raiz do backend.
 * - URLs absolutas (http/https, data:, blob:) são retornadas sem alteração.
 * - Caminhos relativos /uploads/... recebem o prefixo BASE_URL.
 * - Caminhos sem /uploads/ recebem BASE_URL + /uploads/.
 */

const API_URL: string = (import.meta.env?.VITE_API_URL as string) || 'http://localhost:3001/api';

/** URL raiz do backend, sem o sufixo /api */
export const BASE_URL: string = API_URL.replace(/\/api\/?$/, '');

/**
 * Resolve qualquer valor de imagem para uma URL absoluta acessível.
 * - URLs http/https / data: / blob: → retorna sem alterar
 * - /uploads/arquivo.jpg           → BASE_URL + /uploads/arquivo.jpg
 * - arquivo.jpg (sem barra)        → BASE_URL + /uploads/arquivo.jpg
 * - null/undefined/string vazia    → null
 */
export function resolveImg(p?: string | null): string | null {
  if (!p || p.trim() === '') return null;

  // Já é uma URL absoluta ou data/blob URI — usa como está
  if (/^(https?:\/\/|data:|blob:)/i.test(p)) return p;

  // Normaliza para começar com /
  const clean = p.startsWith('/') ? p : `/${p}`;

  // Já tem /uploads/ no caminho
  if (clean.startsWith('/uploads/')) return `${BASE_URL}${clean}`;

  // Fallback: concatena /uploads/
  return `${BASE_URL}/uploads/${p.replace(/^\/+/, '')}`;
}

/** Versão que retorna string vazia em vez de null (útil em src="") */
export function resolveImgSrc(p?: string | null): string {
  return resolveImg(p) ?? '';
}
