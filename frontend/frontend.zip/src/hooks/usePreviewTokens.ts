import { useState, useCallback } from 'react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

const authH = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${localStorage.getItem('token')}`,
});

export interface PreviewToken {
  token: string;
  page_type: string;
  page_id: string;
  label: string;
  expires_at: string;
  created_by: string;
  created_at: string;
  preview_url?: string;
}

interface CreateTokenOptions {
  page_type: 'generic_page' | 'solution_page';
  page_id: string | number;
  label?: string;
  expires_hours?: number;
}

export function usePreviewTokens() {
  const [tokens, setTokens] = useState<PreviewToken[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTokens = useCallback(
    async (page_type: string, page_id: string | number) => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(
          `${API_URL}/admin/preview-tokens?page_type=${page_type}&page_id=${page_id}`,
          { headers: authH() }
        );
        if (!res.ok) throw new Error('Erro ao buscar tokens');
        setTokens(await res.json());
      } catch (e: any) {
        setError(e?.message || 'Erro');
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const createToken = useCallback(
    async (opts: CreateTokenOptions): Promise<PreviewToken | null> => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${API_URL}/admin/preview-tokens`, {
          method: 'POST',
          headers: authH(),
          body: JSON.stringify(opts),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || 'Erro ao criar token');
        }
        const created: PreviewToken = await res.json();
        setTokens((prev) => [created, ...prev]);
        return created;
      } catch (e: any) {
        setError(e?.message || 'Erro');
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const revokeToken = useCallback(async (token: string) => {
    try {
      const res = await fetch(`${API_URL}/admin/preview-tokens/${token}`, {
        method: 'DELETE',
        headers: authH(),
      });
      if (!res.ok) throw new Error('Erro ao revogar');
      setTokens((prev) => prev.filter((t) => t.token !== token));
    } catch (e: any) {
      setError(e?.message || 'Erro');
    }
  }, []);

  /** Constrói a URL pública completa para um token */
  const buildUrl = useCallback((token: string) => {
    const base = window.location.origin;
    return `${base}/preview/${token}`;
  }, []);

  return { tokens, loading, error, fetchTokens, createToken, revokeToken, buildUrl };
}
