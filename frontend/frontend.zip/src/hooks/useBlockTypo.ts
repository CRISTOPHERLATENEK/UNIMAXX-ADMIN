/**
 * useBlockTypo — lê configurações de tipografia por bloco
 * Cada seção tem seus próprios overrides armazenados como:
 *   `{sectionId}.typo_h_color`, `{sectionId}.typo_body_color`, etc.
 */
import { useData } from '@/context/DataContext';

export interface BlockTypo {
  /** Objeto de style para aplicar em <h2>, <h3> de seções claras */
  h: React.CSSProperties;
  /** Objeto de style para aplicar em parágrafos/descrições */
  body: React.CSSProperties;
  /** Objeto de style para aplicar em labels/badges */
  label: React.CSSProperties;
  /** true se tem algum override ativo */
  hasOverride: boolean;
}

export function useBlockTypo(sectionId: string): BlockTypo {
  const { data } = useData();
  const ct = data.content || {};

  const hColor    = ct[`${sectionId}.typo_h_color`]     || '';
  const bodyColor = ct[`${sectionId}.typo_body_color`]   || '';
  const labelColor= ct[`${sectionId}.typo_label_color`]  || '';
  const fontH     = ct[`${sectionId}.font_heading`]      || '';
  const fontB     = ct[`${sectionId}.font_body`]         || '';
  const hWeight   = ct[`${sectionId}.typo_h_weight`]     || '';
  const bodySize  = ct[`${sectionId}.typo_body_size`]    || '';
  const hSpacing  = ct[`${sectionId}.typo_h_spacing`]    || '';
  const hScale    = ct[`${sectionId}.typo_h_scale`]      || '';

  const hasOverride = !!(hColor || bodyColor || labelColor || fontH || fontB || hWeight || bodySize);

  const h: React.CSSProperties = {};
  if (hColor)   h.color      = hColor;
  if (fontH)    h.fontFamily = `'${fontH}', sans-serif`;
  if (hWeight)  h.fontWeight = parseInt(hWeight) as React.CSSProperties['fontWeight'];
  if (hSpacing) h.letterSpacing = `${(parseInt(hSpacing) / 100).toFixed(3)}em`;
  if (hScale)   h.fontSize   = `calc(1em * ${(parseInt(hScale) / 100).toFixed(2)})`;

  const body: React.CSSProperties = {};
  if (bodyColor) body.color      = bodyColor;
  if (fontB)     body.fontFamily = `'${fontB}', sans-serif`;
  if (bodySize)  body.fontSize   = `${bodySize}px`;

  const label: React.CSSProperties = {};
  if (labelColor) label.color = labelColor;

  return { h, body, label, hasOverride };
}
