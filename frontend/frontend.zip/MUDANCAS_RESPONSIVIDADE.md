# Ajustes de Responsividade Mobile

## O que foi alterado

### 1. `src/index.css` (principal)
Adicionado bloco completo de **media queries responsivas** no final do arquivo:
- **`html, body { overflow-x: hidden }`** — elimina scroll horizontal
- **Tablet (≤768px)**: padding lateral reduzido, `py-32`/`py-24` reduzidos para valores adequados, grids 2-col viram 1-col, tipografia `text-6xl/5xl` reescalada
- **Mobile (≤480px)**: padding ainda menor, títulos `clamp()`, grids 4-col viram 2-col, cards com padding compacto
- Ajustes específicos: `.sol-section`, `.sol-card` (carousel de soluções), `#contato` (form 1-coluna), `footer` (search bar 100%, colunas 2/1), `#segmentos` (grid de ícones), modals
- Quebra suave de texto longo

### 2. `src/sections/Header.tsx`
Sem alterações estruturais — o componente já tinha mobile menu próprio, mas agora se beneficia do CSS global.

### 3. `src/sections/Footer.tsx`
- Padding fixo `4rem 2rem 2rem` → `clamp(2.5rem,5vw,4rem) clamp(1rem,3vw,2rem) 2rem`
- Padding fixo `5rem 2rem 3rem` → `clamp(2.5rem,6vw,5rem) clamp(1rem,3vw,2rem) clamp(2rem,4vw,3rem)`
- Padding fixo `1.5rem 2rem` → `1.25rem clamp(1rem,3vw,2rem)`
- Search bar `width: 200` → `width: "min(200px, 100%)"`

### 4. `src/sections/Numbers.tsx`
- Card escuro: padding `72px 48px` → `clamp(2rem,6vw,72px) clamp(1.25rem,4vw,48px)`
- StatCardDark: padding `40px 32px` → `clamp(1.25rem,3.5vw,40px) clamp(1rem,3vw,32px)`
- Grid 3-col agora tem classe `numbers-grid-3` que vira 1-col em mobile
- Padding lateral `0 2rem` → `0 clamp(1rem,3vw,2rem)` (5 ocorrências)

### 5. `src/sections/Contact.tsx`
- Padding lateral `0 2rem` → `0 clamp(1rem,3vw,2rem)`
- Grid principal: `minmax(280px, 1fr)` → `minmax(min(100%, 280px), 1fr)` + gap responsivo
- Form interno: 2-col vira 1-col via CSS global em telas <600px

### 6. `src/sections/Solutions.tsx`
Sem mudanças estruturais — beneficia do CSS global que ajusta `.sol-card`, `.sol-track`, `.sol-grid-responsive` para mobile.

### 7. `src/sections/QuickLinks.tsx`
- Grid `repeat(${cols}, 1fr)` → `repeat(${cols}, minmax(0, 1fr))` (evita overflow)
- Adicionada classe `quicklinks-grid` que CSS global ajusta:
  - ≤768px: 2 colunas
  - ≤420px: 1 coluna

### 8. `src/sections/Testimonials.tsx`
- Padding `clamp(28px,5vw,52px)` + `minHeight: 260` → `clamp(20px,5vw,52px)` + `minHeight: 'clamp(220px, 35vw, 260px)'`
- Botões nav: padding `14px 28px 22px` → `clamp(12px,3vw,14px) clamp(16px,4vw,28px) clamp(16px,4vw,22px)`

### 9. `src/sections/HomeHighlight.tsx`
- Imagem: `minHeight: 'clamp(300px, 40vw, 520px)'` → `'clamp(220px, 40vw, 520px)'`

### 10. `src/components/PageBanner.tsx`
- 7 ocorrências de `padding: '0 2rem'` → `'0 clamp(1rem,3vw,2rem)'`
- 7 ocorrências de `minHeight: 452` → `"clamp(280px, 50vw, 452px)"`

### 11. `src/pages/Home.tsx`
- Hero: `min-h-screen` → `min-h-[88vh] sm:min-h-screen`
- Hero: `py-32` → `py-20 sm:py-32`
- Hero grid: `gap-12` → `gap-8 lg:gap-12`
- FAQ accordion: `px-7 py-5` → `px-5 sm:px-7 py-4 sm:py-5`
- FAQ accordion: `px-7 pb-6` → `px-5 sm:px-7 pb-5 sm:pb-6`
- Contato grid: `gap-16` → `gap-10 lg:gap-16`
- Footer grid: `gap-12 mb-12` → `gap-8 md:gap-12 mb-10 md:mb-12`

## Como aplicar

1. Substitua os arquivos do seu projeto por estes
2. Execute `npm install` (ou `pnpm install`)
3. Execute `npm run dev` para verificar localmente
4. Execute `npm run build` para gerar build de produção

## Backend
**O backend não foi alterado** — o problema era exclusivamente de UI/CSS no frontend.
