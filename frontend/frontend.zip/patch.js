// patch.js  —  run with:  node patch.js
// Place this file inside:  C:\Users\User\Desktop\unimaxx\frontend

const fs = require('fs');
const path = require('path');

function patch(filePath, transforms) {
  const abs = path.resolve(filePath);
  if (!fs.existsSync(abs)) {
    console.error('NOT FOUND: ' + abs);
    process.exit(1);
  }
  let c = fs.readFileSync(abs, 'utf8');
  for (const [desc, fn] of transforms) {
    const before = c;
    c = fn(c);
    if (c === before) {
      console.warn('  [WARN] no change for: ' + desc);
    } else {
      console.log('  [OK] ' + desc);
    }
  }
  fs.writeFileSync(abs, c, 'utf8');
  console.log('Saved: ' + filePath + '\n');
}

// ─── 1. src/types/index.ts ───────────────────────────────────────────────────
patch('src/types/index.ts', [

  ['ContinuousBgMode: add self',
    c => c.replace(
      /ContinuousBgMode\s*=\s*'none'\s*\|\s*'parent'/,
      "ContinuousBgMode = 'none' | 'self' | 'parent'"
    )
  ],

  ['heroLayout: add centered_dark',
    c => c.replace(
      /heroLayout\?:\s*'centered'\s*\|\s*'split'\s*\|\s*'dark_glow'\s*\|\s*'magazine'\s*\|\s*'cinematic'/,
      "heroLayout?: 'centered' | 'centered_dark' | 'split' | 'dark_glow' | 'magazine' | 'cinematic'"
    )
  ],

  ['faq: string[] => object[]',
    c => c.replace(
      /faq\?:\s*string\[\]/,
      "faq?: { question: string; answer: string }[]"
    )
  ],

  ['steps items: add number field',
    c => c.replace(
      /steps\?:\s*\{\s*title:\s*string;\s*description:\s*string\s*\}\[\]/,
      "steps?: { title: string; description: string; number?: string }[]"
    )
  ],

  ['PageBlock: inject missing fields after heroLayout line',
    c => c.replace(
      /(heroLayout\?:[^\n]+\n)/,
      [
        '$1',
        '  // ── per-block colour overrides',
        '  bgColor?: string;',
        '  titleColor?: string;',
        '  subtitleColor?: string;',
        '  ctaBgColor?: string;',
        '  ctaTextColor?: string;',
        '  // ── per-block font sizes',
        '  titleSize?: string;',
        '  subtitleSize?: string;',
        '  // ── layout / style variants',
        '  blockStyle?: string;',
        '  block_style?: string;',
        '  ctaLayout?: string;',
        '  // ── CTA fields',
        '  ctaText?: string;',
        '  ctaUrl?: string;',
        '  // ── integrations block',
        '  logoItems?: { name: string; imageUrl: string }[];',
        '  // ── testimonial block',
        '  company?: string;',
        '',
      ].join('\n')
    )
  ],

]);

// ─── 2. src/components/admin/PageBuilder/PageEditor.tsx ──────────────────────
patch('src/components/admin/PageBuilder/PageEditor.tsx', [

  ['replace react-experimental-dnd with shim',
    c => c.replace(
      /import\s*\{[^}]*\}\s*from\s*'react-experimental-dnd'[^\n]*/,
      [
        '// dnd shim — kept for type-safety while migrating to @dnd-kit',
        'const DndProvider = ({ children }: { children: React.ReactNode }) => <>{children}</>;',
        '// eslint-disable-next-line @typescript-eslint/no-explicit-any',
        'const useDrag = (_cfg?: any) => [{}, () => {}, () => {}] as const;',
        '// eslint-disable-next-line @typescript-eslint/no-explicit-any',
        'const useDrop = (_cfg?: any) => [{}, () => {}] as const;',
      ].join('\n')
    )
  ],

  ['add Box to lucide-react import',
    c => {
      // Already has Box? skip
      if (/\bBox\b/.test(c.split("from 'lucide-react'")[0] || '')) return c;
      // Has a lucide-react import? inject Box into it
      if (c.includes("from 'lucide-react'")) {
        return c.replace(/(import\s*\{)([^}]+)(}\s*from\s*'lucide-react')/, '$1 Box,$2$3');
      }
      // No lucide import at all — prepend one
      return "import { Box } from 'lucide-react';\n" + c;
    }
  ],

]);

console.log('All done! Run: npm run build');
